import { describe, expect, it } from "vitest";
import { LOOKS, lookTotal, shippingFor } from "@/lib/products";

describe("store pricing rules", () => {
  it("ships free at $500 or more", () => {
    expect(shippingFor(500)).toBe(0);
    expect(shippingFor(1280)).toBe(0);
  });
  it("charges $25 shipping under $500", () => {
    expect(shippingFor(320)).toBe(25);
  });
  it("gives 10% off a full look", () => {
    const look = LOOKS.find((l) => l.id === "evening-noir");
    if (!look) throw new Error("the evening-noir look is missing from LOOKS");
    const { sum, bundle } = lookTotal(look);
    expect(sum).toBe(1280 + 2450 + 3900 + 320);
    expect(bundle).toBe(Math.round(sum * 0.9));
  });
});
