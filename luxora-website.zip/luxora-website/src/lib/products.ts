import roseNoir from "@/assets/p-rose-noir-tote.jpg";
import milano from "@/assets/p-milano-crossbody.jpg";
import sienna from "@/assets/p-sienna-top-handle.jpg";
import aurora from "@/assets/p-aurora-ring.jpg";
import lumiere from "@/assets/p-lumiere-hoops.jpg";
import celeste from "@/assets/p-celeste-pendant.jpg";
import chrono from "@/assets/p-chrono-gold.jpg";
import riviera from "@/assets/p-riviera-steel.jpg";
import nuit from "@/assets/p-nuit-rose.jpg";
import eclat from "@/assets/p-eclat-ambre.jpg";
import velours from "@/assets/p-velours-oud.jpg";
import fleur from "@/assets/p-fleur-de-soie.jpg";

export type Category = "handbags" | "jewellery" | "watches" | "fragrance";

export const CATEGORIES: { id: Category; label: string; blurb: string }[] = [
  { id: "handbags", label: "Handbags", blurb: "Hand-stitched Italian leather" },
  { id: "jewellery", label: "Jewellery", blurb: "18k gold, ethically sourced" },
  { id: "watches", label: "Watches", blurb: "Swiss movements, sapphire glass" },
  { id: "fragrance", label: "Fragrance", blurb: "Composed in Grasse" },
];

export type Product = {
  slug: string;
  name: string;
  category: Category;
  price: number;
  image: string;
  tagline: string;
  description: string;
  details: string[];
  options?: { label: string; values: string[] };
  badge?: "New" | "Bestseller" | "Limited";
  rating: number;
  reviews: number;
};

export const PRODUCTS: Product[] = [
  {
    slug: "rose-noir-tote",
    name: "Rosé Noir Tote",
    category: "handbags",
    price: 1280,
    image: roseNoir,
    tagline: "Structured black calfskin with a polished gold clasp",
    description:
      "Hand-stitched Italian leather with a polished gold clasp. Spacious, structured and effortlessly elegant, from boardroom to dinner.",
    details: [
      "Full-grain Italian calfskin",
      "24k gold-plated brass hardware",
      "Suede-lined interior, 3 pockets",
      "32 × 24 × 15 cm",
      "Made in Florence, Italy",
    ],
    options: { label: "Colour", values: ["Noir", "Cognac", "Ivory"] },
    badge: "Bestseller",
    rating: 4.9,
    reviews: 214,
  },
  {
    slug: "milano-mini-crossbody",
    name: "Milano Mini Crossbody",
    category: "handbags",
    price: 890,
    image: milano,
    tagline: "Cognac leather on a fine gold chain",
    description:
      "A compact saddle shape in soft cognac leather, finished with a signature gold push-lock and a detachable curb-chain strap.",
    details: [
      "Vegetable-tanned leather",
      "Detachable 110 cm gold chain",
      "Fits phone, cards and keys",
      "19 × 14 × 6 cm",
      "Made in Milan, Italy",
    ],
    options: { label: "Colour", values: ["Cognac", "Noir", "Bordeaux"] },
    badge: "New",
    rating: 4.8,
    reviews: 96,
  },
  {
    slug: "sienna-top-handle",
    name: "Sienna Top-Handle",
    category: "handbags",
    price: 1540,
    image: sienna,
    tagline: "Bordeaux croc-embossed leather, gold turn-lock",
    description:
      "Our most sculptural silhouette. Glossy croc-embossed leather in deep Bordeaux, a rolled top handle and a gold turn-lock closure.",
    details: [
      "Croc-embossed calf leather",
      "Gold turn-lock and protective feet",
      "Optional shoulder strap included",
      "26 × 19 × 11 cm",
      "Made in Florence, Italy",
    ],
    options: { label: "Colour", values: ["Bordeaux", "Noir"] },
    badge: "Limited",
    rating: 5,
    reviews: 48,
  },
  {
    slug: "aurora-diamond-ring",
    name: "Aurora Diamond Ring",
    category: "jewellery",
    price: 2450,
    image: aurora,
    tagline: "18k gold solitaire, brilliant-cut stone",
    description:
      "An 18k gold band set with a brilliant-cut stone that catches every bit of light. A six-claw setting lifts the stone for maximum brilliance.",
    details: [
      "18k yellow gold",
      "0.75 ct lab-grown diamond, VS1, F colour",
      "IGI certified",
      "Six-claw cathedral setting",
      "Free resizing within 60 days",
    ],
    options: { label: "Ring size", values: ["5", "6", "7", "8"] },
    badge: "Bestseller",
    rating: 4.9,
    reviews: 132,
  },
  {
    slug: "lumiere-gold-hoops",
    name: "Lumière Gold Hoops",
    category: "jewellery",
    price: 680,
    image: lumiere,
    tagline: "Chunky polished 18k gold hoops",
    description:
      "Bold yet weightless. Hollow-formed 18k gold hoops with a mirror polish and a secure hinged clasp for all-day comfort.",
    details: ["18k yellow gold", "Diameter 25 mm, width 6 mm", "Hinged snap closure", "Hypoallergenic"],
    rating: 4.8,
    reviews: 187,
  },
  {
    slug: "celeste-pendant",
    name: "Céleste Pendant",
    category: "jewellery",
    price: 1150,
    image: celeste,
    tagline: "Pear-cut diamond on a fine gold chain",
    description:
      "A single pear-cut stone in a bezel setting, suspended on a whisper-fine 18k gold cable chain. Made to be worn every day.",
    details: [
      "18k yellow gold",
      "0.30 ct pear-cut lab-grown diamond",
      "Adjustable 40 / 45 cm chain",
      "Presented in a LUXORA gift box",
    ],
    badge: "New",
    rating: 4.9,
    reviews: 74,
  },
  {
    slug: "chrono-gold-classic",
    name: "Chrono Gold Classic",
    category: "watches",
    price: 3900,
    image: chrono,
    tagline: "Swiss chronograph with an ivory dial",
    description:
      "Swiss movement, sapphire glass and a hand-finished leather strap made to last a lifetime. A three-register chronograph with timeless proportions.",
    details: [
      "Swiss automatic chronograph movement",
      "40 mm gold PVD stainless steel case",
      "Anti-reflective sapphire crystal",
      "Water resistant to 50 m",
      "5-year international warranty",
    ],
    options: { label: "Strap", values: ["Brown alligator", "Black calf"] },
    badge: "Bestseller",
    rating: 4.9,
    reviews: 158,
  },
  {
    slug: "riviera-steel-automatic",
    name: "Riviera Steel Automatic",
    category: "watches",
    price: 2750,
    image: riviera,
    tagline: "Midnight sunburst dial, steel bracelet",
    description:
      "A clean, everyday automatic with a deep midnight-blue sunburst dial, polished baton markers and a brushed three-link bracelet.",
    details: [
      "Swiss automatic, 42-hour reserve",
      "39 mm 316L stainless steel case",
      "Sapphire crystal, display caseback",
      "Water resistant to 100 m",
      "5-year international warranty",
    ],
    rating: 4.8,
    reviews: 89,
  },
  {
    slug: "nuit-rose-lady",
    name: "Nuit Rose Lady",
    category: "watches",
    price: 3200,
    image: nuit,
    tagline: "Mother-of-pearl dial with diamond markers",
    description:
      "Petite and luminous. A rose-gold case frames a mother-of-pearl dial set with twelve diamond markers, on a fine Milanese mesh bracelet.",
    details: [
      "Swiss quartz movement",
      "30 mm rose gold PVD case",
      "Natural mother-of-pearl dial",
      "12 diamond hour markers (0.06 ct)",
      "Adjustable Milanese mesh bracelet",
    ],
    badge: "Limited",
    rating: 5,
    reviews: 61,
  },
  {
    slug: "eclat-d-ambre",
    name: "Éclat d’Ambre",
    category: "fragrance",
    price: 320,
    image: eclat,
    tagline: "Amber, saffron and warm vanilla",
    description:
      "Amber, saffron and warm vanilla in a hand-blown crystal bottle with a gold cap. A radiant, enveloping signature that lingers for hours.",
    details: [
      "Top: saffron, pink pepper",
      "Heart: amber, jasmine sambac",
      "Base: Madagascar vanilla, labdanum",
      "Eau de Parfum, 22% concentration",
      "Composed in Grasse, France",
    ],
    options: { label: "Size", values: ["50 ml", "100 ml"] },
    badge: "Bestseller",
    rating: 4.9,
    reviews: 341,
  },
  {
    slug: "velours-oud",
    name: "Velours Oud",
    category: "fragrance",
    price: 380,
    image: velours,
    tagline: "Smoked oud, leather and black rose",
    description:
      "Deep and nocturnal. Smoked Cambodian oud meets supple leather and a black rose accord, softened with a whisper of incense.",
    details: [
      "Top: bergamot, cardamom",
      "Heart: black rose, leather",
      "Base: oud, incense, sandalwood",
      "Extrait de Parfum, 25% concentration",
      "Composed in Grasse, France",
    ],
    options: { label: "Size", values: ["50 ml", "100 ml"] },
    badge: "New",
    rating: 4.7,
    reviews: 112,
  },
  {
    slug: "fleur-de-soie",
    name: "Fleur de Soie",
    category: "fragrance",
    price: 290,
    image: fleur,
    tagline: "Peony, white musk and silk accord",
    description:
      "Soft as silk. Fresh peony petals and lychee bloom over a clean white musk, for a fragrance that feels like your skin, only better.",
    details: [
      "Top: lychee, pink grapefruit",
      "Heart: peony, rose de mai",
      "Base: white musk, cashmere wood",
      "Eau de Parfum, 18% concentration",
      "Composed in Grasse, France",
    ],
    options: { label: "Size", values: ["50 ml", "100 ml"] },
    rating: 4.8,
    reviews: 205,
  },
];

export function getProduct(slug: string) {
  return PRODUCTS.find((p) => p.slug === slug);
}

export function formatPrice(n: number) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: 0,
  }).format(n);
}

export type Look = {
  id: string;
  name: string;
  mood: string;
  items: string[];
  discount: number; // fraction off when bought as a full look
};

export const LOOKS: Look[] = [
  {
    id: "evening-noir",
    name: "Evening Noir",
    mood: "Black tie, gold light",
    items: ["rose-noir-tote", "aurora-diamond-ring", "chrono-gold-classic", "eclat-d-ambre"],
    discount: 0.1,
  },
  {
    id: "city-cognac",
    name: "City Cognac",
    mood: "Paris after dark",
    items: ["milano-mini-crossbody", "lumiere-gold-hoops", "nuit-rose-lady", "fleur-de-soie"],
    discount: 0.1,
  },
  {
    id: "bordeaux-velvet",
    name: "Bordeaux Velvet",
    mood: "Late dinner, low light",
    items: ["sienna-top-handle", "celeste-pendant", "riviera-steel-automatic", "velours-oud"],
    discount: 0.1,
  },
];

export function lookTotal(look: Look) {
  const sum = look.items.reduce((acc, s) => acc + (getProduct(s)?.price ?? 0), 0);
  return { sum, bundle: Math.round(sum * (1 - look.discount)) };
}

export const FREE_SHIPPING_THRESHOLD = 500;
export const SHIPPING_FEE = 25;

export function shippingFor(subtotal: number) {
  return subtotal === 0 || subtotal >= FREE_SHIPPING_THRESHOLD ? 0 : SHIPPING_FEE;
}

export const STORE = {
  email: "hello@luxora-store.com",
  phone: "+1 555 010 0199",
  phoneHref: "tel:+15550100199",
  address: "125 Madison Avenue, New York, NY 10016, USA",
  hours: "Monday – Saturday, 10:00 – 20:00",
};
