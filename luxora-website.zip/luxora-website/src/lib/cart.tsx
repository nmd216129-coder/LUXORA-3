import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { getProduct, shippingFor, type Product } from "./products";

export type CartLine = { key: string; slug: string; option?: string | undefined; qty: number; unitPrice: number };

type CartCtx = {
  lines: (CartLine & { product: Product })[];
  count: number;
  subtotal: number;
  shipping: number;
  total: number;
  open: boolean;
  setOpen: (v: boolean) => void;
  add: (slug: string, option?: string | undefined, qty?: number, unitPrice?: number) => void;
  setQty: (key: string, qty: number) => void;
  remove: (key: string) => void;
  clear: () => void;
};

const Ctx = createContext<CartCtx | null>(null);
const STORAGE_KEY = "luxora-bag-v1";

export function CartProvider({ children }: { children: ReactNode }) {
  const [raw, setRaw] = useState<CartLine[]>([]);
  const [open, setOpen] = useState(false);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    try {
      const s = localStorage.getItem(STORAGE_KEY);
      if (s) setRaw(JSON.parse(s));
    } catch {
      /* ignore */
    }
    setReady(true);
  }, []);

  useEffect(() => {
    if (ready) localStorage.setItem(STORAGE_KEY, JSON.stringify(raw));
  }, [raw, ready]);

  const value = useMemo<CartCtx>(() => {
    const lines = raw
      .map((l) => ({ ...l, product: getProduct(l.slug)! }))
      .filter((l) => l.product);
    const subtotal = lines.reduce((a, l) => a + l.unitPrice * l.qty, 0);
    const shipping = shippingFor(subtotal);
    return {
      lines,
      count: lines.reduce((a, l) => a + l.qty, 0),
      subtotal,
      shipping,
      total: subtotal + shipping,
      open,
      setOpen,
      add: (slug, option, qty = 1, unitPrice) => {
        const p = getProduct(slug);
        if (!p) return;
        const price = unitPrice ?? p.price;
        const key = `${slug}|${option ?? ""}|${price}`;
        setRaw((prev) => {
          const found = prev.find((l) => l.key === key);
          if (found) return prev.map((l) => (l.key === key ? { ...l, qty: l.qty + qty } : l));
          return [...prev, { key, slug, option, qty, unitPrice: price }];
        });
      },
      setQty: (key, qty) =>
        setRaw((prev) =>
          qty <= 0 ? prev.filter((l) => l.key !== key) : prev.map((l) => (l.key === key ? { ...l, qty } : l)),
        ),
      remove: (key) => setRaw((prev) => prev.filter((l) => l.key !== key)),
      clear: () => setRaw([]),
    };
  }, [raw, open]);

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useCart() {
  const c = useContext(Ctx);
  if (!c) throw new Error("useCart must be used inside CartProvider");
  return c;
}
