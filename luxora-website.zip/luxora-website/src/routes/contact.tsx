import { createFileRoute } from "@tanstack/react-router";
import { Clock, Mail, MapPin, Phone } from "lucide-react";
import { useState, type FormEvent } from "react";
import { toast } from "sonner";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { STORE } from "@/lib/products";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact & FAQ | LUXORA Atelier New York" },
      { name: "description", content: "Contact LUXORA at 125 Madison Avenue, New York. Shipping, returns, repairs and styling appointments." },
      { property: "og:title", content: "Contact & FAQ | LUXORA" },
      { property: "og:description", content: "Visit the LUXORA atelier or send us a message." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Contact,
});

const FAQ = [
  ["What is LUXORA?", "LUXORA is a premium fashion store selling luxury handbags, gold jewellery, Swiss watches and fragrances."],
  ["Where are LUXORA products made?", "Pieces are made by small partner ateliers in Italy and Switzerland, using traceable leather, gold and sapphire glass. Fragrances are composed in Grasse, France."],
  ["Does LUXORA ship worldwide?", "Yes. We serve customers in 35 countries with insured express shipping. Shipping is free on orders over $500, otherwise a flat $25."],
  ["What is the return and repair policy?", "Unworn items can be returned within 30 days. Every LUXORA piece also includes free lifetime repairs and polishing."],
  ["Can I resize a ring?", "Yes. Aurora rings can be resized free of charge within 60 days of delivery."],
  ["Do you offer gift wrapping?", "Every order arrives in a signature LUXORA box with a handwritten card, at no extra cost."],
];

function Contact() {
  const [sending, setSending] = useState(false);

  const submit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    setSending(true);
    setTimeout(() => {
      setSending(false);
      form.reset();
      toast.success("Thank you, our concierge will reply within 24 hours.");
    }, 700);
  };

  return (
    <div className="container-lux pb-24 pt-32 md:pt-40">
      <p className="eyebrow">Contact</p>
      <h1 className="mt-3 text-5xl md:text-7xl">Visit the Atelier</h1>
      <p className="mt-4 max-w-lg text-muted-foreground">
        Questions, styling advice or private appointments, we would love to hear from you.
      </p>

      <div className="mt-14 grid gap-14 md:grid-cols-2">
        <div className="space-y-6">
          {[
            { icon: MapPin, l: "Atelier", v: STORE.address },
            { icon: Clock, l: "Opening hours", v: STORE.hours },
            { icon: Mail, l: "Email", v: STORE.email, href: `mailto:${STORE.email}` },
            { icon: Phone, l: "Phone", v: STORE.phone, href: STORE.phoneHref },
          ].map(({ icon: Icon, l, v, href }) => (
            <div key={l} className="flex gap-4 border-b border-border pb-6">
              <Icon className="mt-1 size-5 text-gold" />
              <div>
                <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">{l}</p>
                {href ? <a href={href} className="mt-1 block font-display text-2xl hover:text-gold">{v}</a> : <p className="mt-1 font-display text-2xl">{v}</p>}
              </div>
            </div>
          ))}
        </div>

        <form onSubmit={submit} className="space-y-4 rounded-sm border border-border bg-card p-6 md:p-8">
          <h2 className="text-3xl">Send a message</h2>
          <Input required name="name" placeholder="Your name" autoComplete="name" className="h-12 rounded-sm" />
          <Input required type="email" name="email" placeholder="Email address" autoComplete="email" className="h-12 rounded-sm" />
          <Textarea required name="message" rows={5} placeholder="Your message" className="rounded-sm" />
          <Button type="submit" variant="lux" size="lg" className="w-full" disabled={sending}>
            {sending ? "Sending…" : "Send message"}
          </Button>
        </form>
      </div>

      <section className="mx-auto mt-28 max-w-3xl">
        <p className="eyebrow text-center">FAQ</p>
        <h2 className="mt-3 text-center text-4xl md:text-5xl">Frequently asked questions</h2>
        <Accordion type="single" collapsible defaultValue="0" className="mt-10">
          {FAQ.map(([q, a], i) => (
            <AccordionItem key={q} value={String(i)}>
              <AccordionTrigger className="font-display text-xl hover:no-underline">{q}</AccordionTrigger>
              <AccordionContent className="leading-relaxed text-muted-foreground">{a}</AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </section>
    </div>
  );
}
