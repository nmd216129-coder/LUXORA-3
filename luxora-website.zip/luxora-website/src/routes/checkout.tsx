import { createFileRoute, Link } from "@tanstack/react-router";
import { CheckCircle2 } from "lucide-react";
import { useState, type FormEvent } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useCart } from "@/lib/cart";
import { formatPrice } from "@/lib/products";

export const Route = createFileRoute("/checkout")({
  head: () => ({
    meta: [
      { title: "Checkout | LUXORA" },
      { name: "description", content: "Complete your LUXORA order with free insured shipping over $500." },
      { property: "og:title", content: "Checkout | LUXORA" },
      { property: "og:description", content: "Secure checkout at LUXORA." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: Checkout,
});

function Checkout() {
  const { lines, subtotal, shipping, total, clear } = useCart();
  const [order, setOrder] = useState<string | null>(null);

  const submit = (e: FormEvent) => {
    e.preventDefault();
    setOrder(`LX-${Math.floor(100000 + Math.random() * 900000)}`);
    clear();
  };

  if (order) {
    return (
      <div className="container-lux flex flex-col items-center pb-24 pt-40 text-center">
        <CheckCircle2 className="size-14 text-gold" />
        <h1 className="mt-6 text-5xl md:text-6xl">Thank you</h1>
        <p className="mt-4 text-muted-foreground">Order <span className="text-foreground">{order}</span> is confirmed. A receipt is on its way to your inbox.</p>
        <p className="mt-2 text-xs text-muted-foreground">Demo store: no payment was taken.</p>
        <Button variant="lux" size="lg" className="mt-10" asChild>
          <Link to="/shop" search={{ category: undefined }}>Continue shopping</Link>
        </Button>
      </div>
    );
  }

  if (lines.length === 0) {
    return (
      <div className="container-lux pb-24 pt-40 text-center">
        <h1 className="text-5xl">Your bag is empty</h1>
        <Button variant="lux" size="lg" className="mt-8" asChild>
          <Link to="/shop" search={{ category: undefined }}>Discover the collection</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="container-lux pb-24 pt-32 md:pt-40">
      <h1 className="text-5xl md:text-6xl">Checkout</h1>
      <div className="mt-10 grid gap-10 lg:grid-cols-[1fr_400px]">
        <form id="checkout" onSubmit={submit} className="space-y-8">
          <fieldset className="space-y-3">
            <legend className="eyebrow mb-4">Contact</legend>
            <Input required type="email" placeholder="Email" autoComplete="email" className="h-12 rounded-sm" />
            <Input required type="tel" placeholder="Phone" autoComplete="tel" className="h-12 rounded-sm" />
          </fieldset>
          <fieldset className="space-y-3">
            <legend className="eyebrow mb-4">Delivery</legend>
            <div className="grid grid-cols-2 gap-3">
              <Input required placeholder="First name" autoComplete="given-name" className="h-12 rounded-sm" />
              <Input required placeholder="Last name" autoComplete="family-name" className="h-12 rounded-sm" />
            </div>
            <Input required placeholder="Address" autoComplete="street-address" className="h-12 rounded-sm" />
            <div className="grid grid-cols-3 gap-3">
              <Input required placeholder="City" autoComplete="address-level2" className="h-12 rounded-sm" />
              <Input required placeholder="Postcode" autoComplete="postal-code" className="h-12 rounded-sm" />
              <Input required placeholder="Country" autoComplete="country-name" className="h-12 rounded-sm" />
            </div>
          </fieldset>
          <fieldset className="space-y-3">
            <legend className="eyebrow mb-4">Payment</legend>
            <Input required placeholder="Card number" inputMode="numeric" autoComplete="cc-number" className="h-12 rounded-sm" />
            <div className="grid grid-cols-2 gap-3">
              <Input required placeholder="MM / YY" autoComplete="cc-exp" className="h-12 rounded-sm" />
              <Input required placeholder="CVC" inputMode="numeric" autoComplete="cc-csc" className="h-12 rounded-sm" />
            </div>
            <p className="text-xs text-muted-foreground">Demo store: no real payment is processed.</p>
          </fieldset>
        </form>

        <aside className="h-fit rounded-sm border border-border bg-card p-6 lg:sticky lg:top-28">
          <p className="eyebrow">Order summary</p>
          <ul className="mt-6 space-y-4">
            {lines.map((l) => (
              <li key={l.key} className="flex items-center gap-3">
                <img src={l.product.image} alt="" className="size-14 rounded-sm object-cover" width={56} height={56} />
                <div className="flex-1">
                  <p className="font-display text-lg leading-tight">{l.product.name}</p>
                  <p className="text-xs text-muted-foreground">{[l.option, `Qty ${l.qty}`].filter(Boolean).join(" · ")}</p>
                </div>
                <span className="text-sm">{formatPrice(l.unitPrice * l.qty)}</span>
              </li>
            ))}
          </ul>
          <div className="mt-6 space-y-2 border-t border-border pt-6 text-sm">
            <div className="flex justify-between text-muted-foreground"><span>Subtotal</span><span>{formatPrice(subtotal)}</span></div>
            <div className="flex justify-between text-muted-foreground"><span>Insured shipping</span><span>{shipping === 0 ? "Free" : formatPrice(shipping)}</span></div>
            <div className="flex justify-between pt-2 font-display text-3xl"><span>Total</span><span className="text-gold">{formatPrice(total)}</span></div>
          </div>
          <Button type="submit" form="checkout" variant="lux" size="lg" className="mt-6 w-full">Place order</Button>
        </aside>
      </div>
    </div>
  );
}
