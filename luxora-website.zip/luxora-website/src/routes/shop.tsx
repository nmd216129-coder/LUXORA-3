import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { ProductCard } from "@/components/site/ProductCard";
import { CATEGORIES, PRODUCTS, type Category } from "@/lib/products";
import { cn } from "@/lib/utils";

const IDS = CATEGORIES.map((c) => c.id) as string[];

export const Route = createFileRoute("/shop")({
  validateSearch: (s: Record<string, unknown>): { category?: Category | undefined } => {
    const c = s["category"];
    return { category: typeof c === "string" && IDS.includes(c) ? (c as Category) : undefined };
  },
  head: () => ({
    meta: [
      { title: "Shop the Collection | LUXORA" },
      { name: "description", content: "Browse LUXORA handbags, 18k gold jewellery, Swiss watches and fragrances. 12 signature pieces." },
      { property: "og:title", content: "Shop the Collection | LUXORA" },
      { property: "og:description", content: "Handbags, jewellery, watches and fragrance from LUXORA." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Shop,
});

type Sort = "featured" | "low" | "high" | "rating";

function Shop() {
  const { category } = Route.useSearch();
  const [sort, setSort] = useState<Sort>("featured");
  const active = CATEGORIES.find((c) => c.id === category);

  const list = useMemo(() => {
    const l = PRODUCTS.filter((p) => !category || p.category === category);
    if (sort === "low") return [...l].sort((a, b) => a.price - b.price);
    if (sort === "high") return [...l].sort((a, b) => b.price - a.price);
    if (sort === "rating") return [...l].sort((a, b) => b.rating - a.rating);
    return l;
  }, [category, sort]);

  return (
    <div className="container-lux pb-24 pt-32 md:pt-40">
      <p className="eyebrow">{active ? active.blurb : "Autumn · Winter 2026"}</p>
      <h1 className="mt-3 text-5xl md:text-7xl">{active ? active.label : "The Collection"}</h1>

      <div className="mt-10 flex flex-col gap-4 border-y border-border py-4 md:flex-row md:items-center md:justify-between">
        <div className="-mx-1 flex gap-2 overflow-x-auto px-1">
          <FilterLink active={!category} label="All" category={undefined} />
          {CATEGORIES.map((c) => (
            <FilterLink key={c.id} active={category === c.id} label={c.label} category={c.id} />
          ))}
        </div>
        <label className="flex items-center gap-3 text-xs text-muted-foreground">
          Sort
          <select
            value={sort}
            onChange={(e) => setSort(e.target.value as Sort)}
            className="rounded-sm border border-input bg-background px-3 py-2 text-foreground"
          >
            <option value="featured">Featured</option>
            <option value="low">Price: low to high</option>
            <option value="high">Price: high to low</option>
            <option value="rating">Top rated</option>
          </select>
        </label>
      </div>

      <p className="mt-6 text-xs text-muted-foreground">{list.length} pieces</p>
      <div className="mt-6 grid grid-cols-2 gap-x-4 gap-y-12 md:grid-cols-3 md:gap-x-6 lg:grid-cols-4">
        {list.map((p) => (
          <ProductCard key={p.slug} product={p} />
        ))}
      </div>
    </div>
  );
}

function FilterLink({ active, label, category }: { active: boolean; label: string; category?: Category | undefined }) {
  return (
    <Link
      to="/shop"
      search={{ category }}
      className={cn(
        "shrink-0 rounded-full border px-4 py-2 text-[0.65rem] uppercase tracking-[0.2em] transition-colors",
        active ? "border-primary bg-primary text-primary-foreground" : "border-border hover:border-gold",
      )}
    >
      {label}
    </Link>
  );
}
