import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { CountUp } from "@/components/site/CountUp";
import atelier from "@/assets/atelier.jpg";
import hero from "@/assets/hero.jpg";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "Our Story | LUXORA Ateliers in Italy & Switzerland" },
      { name: "description", content: "Founded in 2018, LUXORA works with small ateliers in Italy and Switzerland to craft handbags, jewellery, watches and fragrance made to last." },
      { property: "og:title", content: "Our Story | LUXORA" },
      { property: "og:description", content: "Luxury should feel personal. Meet the ateliers behind LUXORA." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: About,
});

const STATS = [
  { value: 12000, suffix: "+", label: "Happy clients" },
  { value: 480, suffix: "+", label: "Signature pieces" },
  { value: 35, suffix: "", label: "Countries served" },
  { value: 8, suffix: "", label: "Years of craft" },
];

const VALUES = [
  { t: "Italian Craft", d: "Hand-stitched leather and gold-finished hardware from family workshops in Florence and Milan." },
  { t: "Ethical Sourcing", d: "Traceable leather, recycled 18k gold and lab-grown diamonds from partners we know by name." },
  { t: "Lifetime Care", d: "Free repairs, re-stitching and polishing for every LUXORA piece, for as long as you own it." },
];

function About() {
  return (
    <>
      <section className="container-lux pb-20 pt-32 md:pt-40">
        <p className="eyebrow">Our Story · Since 2018</p>
        <h1 className="mt-4 max-w-4xl text-5xl leading-[1] md:text-8xl">
          Made for those who <em className="text-gold-gradient">notice the details</em>
        </h1>
        <div className="mt-12 grid gap-8 text-foreground/80 md:grid-cols-2 md:text-lg">
          <p className="leading-relaxed">
            LUXORA began with one idea: luxury should feel personal. Every piece is cut from carefully chosen
            materials, finished by hand and designed to be worn for years, not seasons.
          </p>
          <p className="leading-relaxed">
            From Italian leather to Swiss movements, we work with small ateliers that share our obsession with
            quality. No middlemen, no seasonal markdowns, just pieces we would wear ourselves.
          </p>
        </div>
      </section>

      <img src={atelier} alt="LUXORA artisan at work in Florence" loading="lazy" width={1408} height={1008} className="h-[60vh] w-full object-cover" />

      <section className="container-lux grid gap-10 py-24 md:grid-cols-3">
        {VALUES.map((v, i) => (
          <div key={v.t} className="border-t border-gold/30 pt-8">
            <p className="font-display text-5xl text-gold">0{i + 1}</p>
            <h2 className="mt-4 text-3xl">{v.t}</h2>
            <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{v.d}</p>
          </div>
        ))}
      </section>

      <section className="bg-ink">
        <div className="container-lux grid grid-cols-2 gap-8 py-20 md:grid-cols-4">
          {STATS.map((s) => (
            <div key={s.label} className="text-center">
              <p className="font-display text-5xl text-gold md:text-6xl">
                <CountUp value={s.value} suffix={s.suffix} />
              </p>
              <p className="mt-2 text-xs uppercase tracking-[0.2em] text-muted-foreground">{s.label}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="container-lux grid items-center gap-12 py-24 md:grid-cols-2">
        <img src={hero} alt="LUXORA Autumn Winter 2026 campaign" loading="lazy" width={1600} height={1008} className="aspect-[4/3] w-full rounded-sm object-cover object-right" />
        <div>
          <h2 className="text-4xl md:text-5xl">Visit the Madison Avenue atelier</h2>
          <p className="mt-4 leading-relaxed text-muted-foreground">
            Private styling appointments, engraving and fittings, Monday to Saturday in New York.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Button variant="lux" size="lg" asChild><Link to="/contact">Book an appointment</Link></Button>
            <Button variant="luxOutline" size="lg" asChild><Link to="/shop" search={{ category: undefined }}>Shop now</Link></Button>
          </div>
        </div>
      </section>
    </>
  );
}
