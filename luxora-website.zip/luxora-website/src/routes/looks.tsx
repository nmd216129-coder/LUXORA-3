import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, ArrowRight } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { useCart } from "@/lib/cart";
import { LOOKS, formatPrice, getProduct, lookTotal } from "@/lib/products";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/looks")({
  head: () => ({
    meta: [
      { title: "Try the Look | Styled Outfits by LUXORA" },
      { name: "description", content: "Complete looks styled by LUXORA: a handbag, jewellery, a watch and a fragrance. Save 10% on the full look." },
      { property: "og:title", content: "Try the Look | LUXORA" },
      { property: "og:description", content: "Styled LUXORA looks, 10% off when you buy the full look." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Looks,
});

function Looks() {
  const [i, setI] = useState(0);
  const { add, setOpen } = useCart();
  const look = LOOKS[i] ?? LOOKS[0]!;
  const items = look.items.map((s) => getProduct(s)!);
  const { sum, bundle } = lookTotal(look);

  const addAll = () => {
    items.forEach((p) => add(p.slug, p.options?.values[0], 1, Math.round(p.price * (1 - look.discount))));
    toast.success(`${look.name} look added, you saved ${formatPrice(sum - bundle)}`);
    setOpen(true);
  };

  return (
    <div className="container-lux pb-24 pt-32 md:pt-40">
      <p className="eyebrow">Try the Look</p>
      <div className="mt-3 flex flex-wrap items-end justify-between gap-6">
        <h1 className="text-5xl md:text-7xl">{look.name}<span className="block text-2xl italic text-muted-foreground md:text-3xl">{look.mood}</span></h1>
        <div className="flex items-center gap-3">
          <button aria-label="Previous look" onClick={() => setI((i - 1 + LOOKS.length) % LOOKS.length)} className="grid size-12 place-items-center rounded-full border border-border hover:border-gold"><ArrowLeft className="size-4" /></button>
          <button aria-label="Next look" onClick={() => setI((i + 1) % LOOKS.length)} className="grid size-12 place-items-center rounded-full border border-border hover:border-gold"><ArrowRight className="size-4" /></button>
          <div className="ml-2 flex gap-2">
            {LOOKS.map((l, idx) => (
              <button key={l.id} aria-label={l.name} onClick={() => setI(idx)} className={cn("h-1 rounded-full transition-all", idx === i ? "w-8 bg-primary" : "w-3 bg-border")} />
            ))}
          </div>
        </div>
      </div>

      <div className="mt-12 grid gap-8 lg:grid-cols-[1fr_380px]">
        <div key={look.id} className="grid animate-rise grid-cols-2 gap-3 md:gap-5">
          {items.map((p) => (
            <Link key={p.slug} to="/product/$slug" params={{ slug: p.slug }} className="group relative overflow-hidden rounded-sm">
              <img src={p.image} alt={p.name} loading="lazy" width={1024} height={1024} className="aspect-square w-full object-cover transition-transform duration-700 group-hover:scale-105" />
              <div className="absolute inset-0 bg-fade-up opacity-80" />
              <div className="absolute bottom-0 p-4">
                <p className="font-display text-xl md:text-2xl">{p.name}</p>
                <p className="text-xs text-gold-soft">{formatPrice(p.price)}</p>
              </div>
            </Link>
          ))}
        </div>

        <aside className="h-fit rounded-sm border border-border bg-card p-6 lg:sticky lg:top-28">
          <div className="flex justify-between text-xs uppercase tracking-[0.2em] text-muted-foreground">
            <span>In this look</span><span>{items.length} pieces</span>
          </div>
          <ul className="mt-6 space-y-4">
            {items.map((p) => (
              <li key={p.slug} className="flex items-center gap-3">
                <img src={p.image} alt="" className="size-12 rounded-sm object-cover" loading="lazy" width={48} height={48} />
                <span className="flex-1 font-display text-lg">{p.name}</span>
                <span className="text-sm text-muted-foreground">{formatPrice(p.price)}</span>
              </li>
            ))}
          </ul>
          <div className="mt-6 border-t border-border pt-6">
            <div className="flex items-end justify-between">
              <div>
                <p className="text-sm">Complete the look</p>
                <p className="text-xs text-muted-foreground">Save {Math.round(look.discount * 100)}% on all pieces</p>
              </div>
              <div className="text-right">
                <p className="text-xs text-muted-foreground line-through">{formatPrice(sum)}</p>
                <p className="font-display text-3xl text-gold">{formatPrice(bundle)}</p>
              </div>
            </div>
            <Button variant="lux" size="lg" className="mt-6 w-full" onClick={addAll}>
              Add full look to bag <ArrowRight />
            </Button>
          </div>
        </aside>
      </div>
    </div>
  );
}
