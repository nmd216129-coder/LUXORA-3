import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Gem, Leaf, ShieldCheck, Truck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ProductCard } from "@/components/site/ProductCard";
import { CountUp } from "@/components/site/CountUp";
import { CATEGORIES, PRODUCTS, getProduct } from "@/lib/products";
import hero from "@/assets/hero.jpg";
import lookEvening from "@/assets/look-evening.jpg";
import atelier from "@/assets/atelier.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "LUXORA | Luxury Handbags, Jewellery, Watches & Fragrance" },
      {
        name: "description",
        content:
          "Shop LUXORA: Italian leather handbags, 18k gold jewellery, Swiss watches and Grasse fragrances. Free insured shipping over $500.",
      },
      { property: "og:title", content: "LUXORA | Wear the Extraordinary" },
      {
        property: "og:description",
        content: "Italian leather handbags, 18k gold jewellery, Swiss watches and Grasse fragrances.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const CATEGORY_COVER: Record<string, string> = {
  handbags: "rose-noir-tote",
  jewellery: "aurora-diamond-ring",
  watches: "chrono-gold-classic",
  fragrance: "eclat-d-ambre",
};

const STATS = [
  { value: 12000, suffix: "+", label: "Happy clients" },
  { value: 480, suffix: "+", label: "Signature pieces" },
  { value: 35, suffix: "", label: "Countries served" },
  { value: 8, suffix: "", label: "Years of craft" },
];

const REVIEWS = [
  { quote: "The Rosé Noir Tote is even more beautiful in person. The leather smells like a workshop in Florence.", name: "Amelia R.", city: "London" },
  { quote: "I bought the Chrono Gold for my husband's 40th. Packaging, delivery and the watch itself: flawless.", name: "Sofia M.", city: "Dubai" },
  { quote: "Éclat d’Ambre lasts all day and I get asked about it every single time.", name: "Nadia K.", city: "New York" },
];

function Index() {
  const featured = PRODUCTS.filter((p) => p.badge === "Bestseller");
  const newIn = PRODUCTS.filter((p) => p.badge === "New" || p.badge === "Limited");

  return (
    <>
      {/* Hero */}
      <section className="relative flex min-h-[100svh] items-end overflow-hidden md:items-center">
        <img
          src={hero}
          alt="Model in a black coat carrying the LUXORA Rosé Noir Tote"
          width={1600}
          height={1008}
          className="absolute inset-0 h-full w-full object-cover object-[70%_center]"
        />
        <div className="absolute inset-0 bg-fade-up md:bg-fade-side" />
        <div className="container-lux relative pb-16 pt-32 md:pb-0">
          <div className="max-w-xl animate-rise">
            <p className="eyebrow">Autumn · Winter 2026</p>
            <h1 className="mt-5 text-6xl leading-[0.95] md:text-8xl">
              Wear the <em className="text-gold-gradient">Extraordinary</em>
            </h1>
            <p className="mt-6 max-w-md text-sm leading-relaxed text-foreground/75 md:text-base">
              Timeless pieces crafted in gold and leather by small ateliers in Italy and Switzerland.
            </p>
            <div className="mt-10 flex flex-wrap gap-3">
              <Button variant="lux" size="lg" asChild>
                <Link to="/shop" search={{ category: undefined }}>Shop the collection</Link>
              </Button>
              <Button variant="luxOutline" size="lg" asChild>
                <Link to="/looks">Try the look</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Promise strip */}
      <section className="border-y border-border bg-ink">
        <div className="container-lux grid grid-cols-2 gap-6 py-8 text-xs text-muted-foreground md:grid-cols-4">
          {[
            { icon: Truck, t: "Free insured shipping", s: "On orders over $500" },
            { icon: ShieldCheck, t: "30-day returns", s: "Unworn items, no questions" },
            { icon: Gem, t: "Lifetime care", s: "Free repairs & polishing" },
            { icon: Leaf, t: "Ethically sourced", s: "Traceable gold & leather" },
          ].map(({ icon: Icon, t, s }) => (
            <div key={t} className="flex items-start gap-3">
              <Icon className="mt-0.5 size-4 shrink-0 text-gold" />
              <div>
                <p className="text-foreground">{t}</p>
                <p>{s}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Categories */}
      <section className="container-lux py-24">
        <div className="flex items-end justify-between gap-6">
          <div>
            <p className="eyebrow">The Collections</p>
            <h2 className="mt-3 text-4xl md:text-6xl">Four houses, one obsession</h2>
          </div>
        </div>
        <div className="mt-12 grid grid-cols-2 gap-3 md:grid-cols-4 md:gap-5">
          {CATEGORIES.map((c) => {
            const p = getProduct(CATEGORY_COVER[c.id] ?? "")!;
            return (
              <Link
                key={c.id}
                to="/shop"
                search={{ category: c.id }}
                className="group relative block overflow-hidden rounded-sm"
              >
                <img src={p.image} alt={c.label} loading="lazy" width={1024} height={1024} className="aspect-[3/4] w-full object-cover transition-transform duration-700 group-hover:scale-105" />
                <div className="absolute inset-0 bg-fade-up" />
                <div className="absolute inset-x-0 bottom-0 p-4 md:p-6">
                  <h3 className="text-2xl md:text-3xl">{c.label}</h3>
                  <p className="mt-1 text-[0.7rem] text-muted-foreground">{c.blurb}</p>
                  <span className="mt-3 inline-flex items-center gap-2 text-[0.6rem] uppercase tracking-[0.25em] text-gold">
                    Explore <ArrowRight className="size-3 transition-transform group-hover:translate-x-1" />
                  </span>
                </div>
              </Link>
            );
          })}
        </div>
      </section>

      {/* Bestsellers */}
      <section className="container-lux pb-24">
        <div className="flex items-end justify-between gap-6">
          <div>
            <p className="eyebrow">Most loved</p>
            <h2 className="mt-3 text-4xl md:text-6xl">Bestsellers</h2>
          </div>
          <Link to="/shop" search={{ category: undefined }} className="hidden items-center gap-2 text-[0.7rem] uppercase tracking-[0.25em] text-gold md:inline-flex">
            View all 12 pieces <ArrowRight className="size-3" />
          </Link>
        </div>
        <div className="mt-12 grid grid-cols-2 gap-x-4 gap-y-10 md:grid-cols-4 md:gap-x-6">
          {featured.map((p) => (
            <ProductCard key={p.slug} product={p} />
          ))}
        </div>
      </section>

      {/* Look teaser */}
      <section className="bg-ink">
        <div className="container-lux grid items-center gap-12 py-24 md:grid-cols-2">
          <img src={lookEvening} alt="The City Cognac look" loading="lazy" width={1008} height={1312} className="aspect-[4/5] w-full rounded-sm object-cover" />
          <div>
            <p className="eyebrow">Try the Look</p>
            <h2 className="mt-3 text-5xl md:text-7xl">City Cognac</h2>
            <p className="mt-6 max-w-md leading-relaxed text-muted-foreground">
              The Milano Mini Crossbody, Lumière hoops, the Nuit Rose watch and a veil of Fleur de Soie. Styled
              together, and 10% less when you take the whole look home.
            </p>
            <Button variant="lux" size="lg" className="mt-10" asChild>
              <Link to="/looks">Shop complete looks</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* New & limited */}
      <section className="container-lux py-24">
        <p className="eyebrow">Just arrived</p>
        <h2 className="mt-3 text-4xl md:text-6xl">New & limited</h2>
        <div className="mt-12 grid grid-cols-2 gap-x-4 gap-y-10 md:grid-cols-5 md:gap-x-6">
          {newIn.map((p) => (
            <ProductCard key={p.slug} product={p} />
          ))}
        </div>
      </section>

      {/* Atelier */}
      <section className="relative overflow-hidden">
        <img src={atelier} alt="Artisan hand-stitching a leather handbag" loading="lazy" width={1408} height={1008} className="absolute inset-0 h-full w-full object-cover" />
        <div className="absolute inset-0 bg-fade-side" />
        <div className="container-lux relative py-32">
          <div className="max-w-lg">
            <p className="eyebrow">Our Story</p>
            <h2 className="mt-3 text-4xl md:text-6xl">Made for those who notice the details</h2>
            <p className="mt-6 leading-relaxed text-foreground/75">
              Every piece is cut from carefully chosen materials, finished by hand and designed to be worn for
              years, not seasons.
            </p>
            <div className="mt-10 grid grid-cols-2 gap-6">
              {STATS.map((s) => (
                <div key={s.label}>
                  <p className="font-display text-4xl text-gold">
                    <CountUp value={s.value} suffix={s.suffix} />
                  </p>
                  <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">{s.label}</p>
                </div>
              ))}
            </div>
            <Button variant="luxOutline" size="lg" className="mt-10" asChild>
              <Link to="/about">Read our story</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Reviews */}
      <section className="container-lux py-24">
        <p className="eyebrow text-center">Client notes</p>
        <div className="mt-12 grid gap-10 md:grid-cols-3">
          {REVIEWS.map((r) => (
            <figure key={r.name} className="border-t border-gold/30 pt-8">
              <blockquote className="font-display text-2xl italic leading-snug">“{r.quote}”</blockquote>
              <figcaption className="mt-6 text-xs uppercase tracking-[0.2em] text-muted-foreground">
                {r.name} · {r.city}
              </figcaption>
            </figure>
          ))}
        </div>
      </section>
    </>
  );
}
