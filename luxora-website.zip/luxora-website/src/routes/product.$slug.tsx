import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { Check, Minus, Plus, Star, Truck, RotateCcw, Gem } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { ProductCard } from "@/components/site/ProductCard";
import { useCart } from "@/lib/cart";
import { CATEGORIES, PRODUCTS, formatPrice, getProduct } from "@/lib/products";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/product/$slug")({
  loader: ({ params }) => {
    const product = getProduct(params.slug);
    if (!product) throw notFound();
    return { product };
  },
  head: ({ loaderData }) => {
    const p = loaderData?.product;
    if (!p) return { meta: [{ title: "Piece not found | LUXORA" }, { name: "robots", content: "noindex" }] };
    return {
      meta: [
        { title: `${p.name} | LUXORA` },
        { name: "description", content: p.description },
        { property: "og:title", content: `${p.name} | LUXORA` },
        { property: "og:description", content: p.tagline },
        { property: "og:type", content: "product" },
        { name: "twitter:card", content: "summary_large_image" },
      ],
    };
  },
  notFoundComponent: () => (
    <div className="container-lux py-40 text-center">
      <h1 className="text-5xl">This piece is no longer available</h1>
      <Button variant="lux" size="lg" className="mt-8" asChild>
        <Link to="/shop" search={{ category: undefined }}>Back to the collection</Link>
      </Button>
    </div>
  ),
  component: ProductPage,
});

function ProductPage() {
  const { product: p } = Route.useLoaderData();
  const { add, setOpen } = useCart();
  const [option, setOption] = useState(p.options?.values[0]);
  const [qty, setQty] = useState(1);
  const cat = CATEGORIES.find((c) => c.id === p.category)!;
  const related = PRODUCTS.filter((x) => x.category === p.category && x.slug !== p.slug);

  return (
    <div className="pt-20 md:pt-28">
      <div className="container-lux">
        <nav className="py-4 text-xs text-muted-foreground">
          <Link to="/shop" search={{ category: undefined }} className="hover:text-foreground">Shop</Link>
          <span className="mx-2">/</span>
          <Link to="/shop" search={{ category: p.category }} className="hover:text-foreground">{cat.label}</Link>
          <span className="mx-2">/</span>
          <span className="text-foreground">{p.name}</span>
        </nav>

        <div className="grid gap-10 md:grid-cols-2 md:gap-16">
          <div className="overflow-hidden rounded-sm bg-card">
            <img src={p.image} alt={p.name} width={1024} height={1024} className="aspect-square w-full object-cover" />
          </div>

          <div className="md:py-6">
            {p.badge && <p className="eyebrow">{p.badge}</p>}
            <h1 className="mt-3 text-5xl leading-none md:text-6xl">{p.name}</h1>
            <p className="mt-3 text-muted-foreground">{p.tagline}</p>
            <div className="mt-4 flex items-center gap-2 text-sm">
              <div className="flex">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} className={cn("size-4", i < Math.round(p.rating) ? "fill-gold text-gold" : "text-muted-foreground")} />
                ))}
              </div>
              <span className="text-muted-foreground">{p.rating.toFixed(1)} ({p.reviews} reviews)</span>
            </div>
            <p className="mt-8 font-display text-4xl text-gold-soft">{formatPrice(p.price)}</p>

            <p className="mt-8 leading-relaxed text-foreground/80">{p.description}</p>

            {p.options && (
              <div className="mt-8">
                <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">
                  {p.options.label}: <span className="text-foreground">{option}</span>
                </p>
                <div className="mt-3 flex flex-wrap gap-2">
                  {p.options.values.map((v) => (
                    <button
                      key={v}
                      onClick={() => setOption(v)}
                      className={cn(
                        "min-w-12 rounded-sm border px-4 py-2 text-sm transition-colors",
                        option === v ? "border-primary bg-primary text-primary-foreground" : "border-border hover:border-gold",
                      )}
                    >
                      {v}
                    </button>
                  ))}
                </div>
              </div>
            )}

            <div className="mt-8 flex gap-3">
              <div className="flex items-center border border-border">
                <button className="p-3" aria-label="Decrease quantity" onClick={() => setQty(Math.max(1, qty - 1))}><Minus className="size-4" /></button>
                <span className="w-8 text-center">{qty}</span>
                <button className="p-3" aria-label="Increase quantity" onClick={() => setQty(qty + 1)}><Plus className="size-4" /></button>
              </div>
              <Button
                variant="lux"
                size="lg"
                className="flex-1"
                onClick={() => {
                  add(p.slug, option, qty);
                  toast.success(`${p.name} added to your bag`);
                  setOpen(true);
                }}
              >
                Add to bag
              </Button>
            </div>

            <ul className="mt-10 space-y-3 border-t border-border pt-8 text-sm text-foreground/80">
              {p.details.map((d) => (
                <li key={d} className="flex gap-3"><Check className="mt-0.5 size-4 shrink-0 text-gold" />{d}</li>
              ))}
            </ul>

            <div className="mt-8 grid grid-cols-3 gap-3 text-center text-[0.65rem] uppercase tracking-[0.15em] text-muted-foreground">
              <div className="border border-border p-3"><Truck className="mx-auto mb-2 size-4 text-gold" />Insured shipping</div>
              <div className="border border-border p-3"><RotateCcw className="mx-auto mb-2 size-4 text-gold" />30-day returns</div>
              <div className="border border-border p-3"><Gem className="mx-auto mb-2 size-4 text-gold" />Lifetime care</div>
            </div>
          </div>
        </div>

        {related.length > 0 && (
          <section className="py-24">
            <p className="eyebrow">More {cat.label.toLowerCase()}</p>
            <h2 className="mt-3 text-4xl md:text-5xl">You may also love</h2>
            <div className="mt-10 grid grid-cols-2 gap-x-4 gap-y-10 md:grid-cols-4 md:gap-x-6">
              {related.map((r) => <ProductCard key={r.slug} product={r} />)}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}
