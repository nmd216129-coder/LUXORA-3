import { Link } from "@tanstack/react-router";
import { Star } from "lucide-react";
import { toast } from "sonner";
import { useCart } from "@/lib/cart";
import { formatPrice, type Product } from "@/lib/products";

export function ProductCard({ product }: { product: Product }) {
  const { add } = useCart();
  return (
    <article className="group">
      <Link to="/product/$slug" params={{ slug: product.slug }} className="relative block overflow-hidden rounded-sm bg-card">
        <img
          src={product.image}
          alt={product.name}
          loading="lazy"
          width={1024}
          height={1024}
          className="aspect-[4/5] w-full object-cover transition-transform duration-700 group-hover:scale-105"
        />
        {product.badge && (
          <span className="absolute left-3 top-3 bg-background/80 px-2.5 py-1 text-[0.6rem] uppercase tracking-[0.25em] text-gold backdrop-blur">
            {product.badge}
          </span>
        )}
        <button
          onClick={(e) => {
            e.preventDefault();
            add(product.slug, product.options?.values[0]);
            toast.success(`${product.name} added to your bag`);
          }}
          className="absolute inset-x-3 bottom-3 translate-y-2 bg-primary py-3 text-[0.65rem] font-semibold uppercase tracking-[0.25em] text-primary-foreground opacity-0 transition-all duration-300 group-hover:translate-y-0 group-hover:opacity-100 max-md:hidden"
        >
          Add to bag
        </button>
      </Link>
      <div className="mt-4 flex items-start justify-between gap-3">
        <div>
          <Link to="/product/$slug" params={{ slug: product.slug }} className="font-display text-xl leading-tight hover:text-gold">
            {product.name}
          </Link>
          <p className="mt-1 flex items-center gap-1 text-xs text-muted-foreground">
            <Star className="size-3 fill-gold text-gold" /> {product.rating.toFixed(1)} · {product.reviews} reviews
          </p>
        </div>
        <p className="text-sm text-gold-soft">{formatPrice(product.price)}</p>
      </div>
    </article>
  );
}
