import { Link } from "@tanstack/react-router";
import { Menu, ShoppingBag } from "lucide-react";
import { useEffect, useState } from "react";
import { Sheet, SheetContent, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { useCart } from "@/lib/cart";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/shop", label: "Shop" },
  { to: "/looks", label: "Try the Look" },
  { to: "/about", label: "About" },
  { to: "/contact", label: "Contact" },
] as const;

export function Header() {
  const { count, setOpen } = useCart();
  const [scrolled, setScrolled] = useState(false);
  const [menu, setMenu] = useState(false);

  useEffect(() => {
    const on = () => setScrolled(window.scrollY > 20);
    on();
    window.addEventListener("scroll", on, { passive: true });
    return () => window.removeEventListener("scroll", on);
  }, []);

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-all duration-500",
        scrolled ? "border-b border-border bg-background/90 backdrop-blur-md" : "bg-transparent",
      )}
    >
      <div className="container-lux flex h-16 items-center justify-between md:h-20">
        <Sheet open={menu} onOpenChange={setMenu}>
          <SheetTrigger asChild>
            <button aria-label="Open menu" className="p-2 -ml-2 md:hidden">
              <Menu className="size-5" />
            </button>
          </SheetTrigger>
          <SheetContent side="left" className="w-72 border-border bg-background">
            <SheetTitle className="font-display text-2xl tracking-[0.3em] text-gold">LUXORA</SheetTitle>
            <nav className="mt-10 flex flex-col gap-6">
              <Link to="/" onClick={() => setMenu(false)} className="font-display text-3xl">
                Home
              </Link>
              {NAV.map((n) => (
                <Link
                  key={n.to}
                  to={n.to}
                  onClick={() => setMenu(false)}
                  className="font-display text-3xl"
                  activeProps={{ className: "text-gold" }}
                >
                  {n.label}
                </Link>
              ))}
            </nav>
          </SheetContent>
        </Sheet>

        <Link to="/" className="font-display text-xl tracking-[0.4em] md:text-2xl">
          LUXORA
        </Link>

        <nav className="hidden items-center gap-10 md:flex">
          {NAV.map((n) => (
            <Link
              key={n.to}
              to={n.to}
              className="text-[0.7rem] uppercase tracking-[0.25em] text-foreground/80 transition-colors hover:text-gold"
              activeProps={{ className: "text-gold" }}
            >
              {n.label}
            </Link>
          ))}
        </nav>

        <button
          onClick={() => setOpen(true)}
          className="flex items-center gap-2 text-[0.7rem] uppercase tracking-[0.25em] transition-colors hover:text-gold"
          aria-label={`Open bag, ${count} items`}
        >
          <ShoppingBag className="size-5 md:size-4" />
          <span className="hidden md:inline">Bag</span>
          <span className="grid size-5 place-items-center rounded-full bg-primary text-[0.6rem] font-semibold tracking-normal text-primary-foreground">
            {count}
          </span>
        </button>
      </div>
    </header>
  );
}
