import { Link } from "@tanstack/react-router";
import { Instagram, Facebook, Youtube } from "lucide-react";
import { STORE } from "@/lib/products";

export function Footer() {
  return (
    <footer className="border-t border-border bg-ink">
      <div className="container-lux grid gap-12 py-16 md:grid-cols-4">
        <div className="md:col-span-2">
          <div className="font-display text-3xl tracking-[0.4em]">LUXORA</div>
          <p className="mt-4 max-w-sm text-sm leading-relaxed text-muted-foreground">
            Handbags, gold jewellery, Swiss watches and fragrance, made by small ateliers in Italy and
            Switzerland. Wear the extraordinary.
          </p>
          <div className="mt-6 flex gap-4 text-muted-foreground">
            <a href="https://www.instagram.com/luxora" aria-label="Instagram" className="hover:text-gold"><Instagram className="size-4" /></a>
            <a href="https://www.facebook.com/luxora" aria-label="Facebook" className="hover:text-gold"><Facebook className="size-4" /></a>
            <a href="https://www.youtube.com/@luxora" aria-label="YouTube" className="hover:text-gold"><Youtube className="size-4" /></a>
          </div>
        </div>
        <div>
          <div className="eyebrow">Explore</div>
          <ul className="mt-5 space-y-3 text-sm text-muted-foreground">
            <li><Link to="/shop" search={{ category: undefined }} className="hover:text-foreground">Shop all</Link></li>
            <li><Link to="/looks" className="hover:text-foreground">Try the Look</Link></li>
            <li><Link to="/about" className="hover:text-foreground">Our story</Link></li>
            <li><Link to="/contact" className="hover:text-foreground">Contact & FAQ</Link></li>
          </ul>
        </div>
        <div>
          <div className="eyebrow">Atelier</div>
          <address className="mt-5 space-y-3 text-sm not-italic text-muted-foreground">
            <p>{STORE.address}</p>
            <p>{STORE.hours}</p>
            <p><a href={`mailto:${STORE.email}`} className="hover:text-foreground">{STORE.email}</a></p>
            <p><a href={STORE.phoneHref} className="hover:text-foreground">{STORE.phone}</a></p>
          </address>
        </div>
      </div>
      <div className="border-t border-border">
        <div className="container-lux flex flex-col gap-2 py-6 text-xs text-muted-foreground md:flex-row md:justify-between">
          <p>© 2026 LUXORA Fashion Ltd. Crafted with passion.</p>
          <p>Free insured shipping over $500 · 30-day returns · Lifetime repairs</p>
        </div>
      </div>
    </footer>
  );
}
