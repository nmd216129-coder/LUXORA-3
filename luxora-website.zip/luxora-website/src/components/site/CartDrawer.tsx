import { Link } from "@tanstack/react-router";
import { Minus, Plus, X } from "lucide-react";
import { Sheet, SheetContent, SheetTitle } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { useCart } from "@/lib/cart";
import { FREE_SHIPPING_THRESHOLD, formatPrice } from "@/lib/products";

export function CartDrawer() {
  const { open, setOpen, lines, subtotal, shipping, total, setQty, remove } = useCart();
  const remaining = FREE_SHIPPING_THRESHOLD - subtotal;

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetContent className="flex w-full flex-col border-border bg-background p-0 sm:max-w-md">
        <div className="border-b border-border p-6">
          <SheetTitle className="font-display text-3xl font-normal">Your bag</SheetTitle>
          {lines.length > 0 && (
            <p className="mt-2 text-xs text-muted-foreground">
              {remaining > 0
                ? `Add ${formatPrice(remaining)} more for free insured shipping`
                : "You qualify for free insured shipping"}
            </p>
          )}
        </div>

        {lines.length === 0 ? (
          <div className="flex flex-1 flex-col items-center justify-center gap-6 p-6 text-center">
            <p className="font-display text-2xl text-muted-foreground">Your bag is empty</p>
            <Button variant="luxOutline" size="lg" asChild onClick={() => setOpen(false)}>
              <Link to="/shop" search={{ category: undefined }}>Discover the collection</Link>
            </Button>
          </div>
        ) : (
          <>
            <ul className="flex-1 divide-y divide-border overflow-y-auto px-6">
              {lines.map((l) => (
                <li key={l.key} className="flex gap-4 py-5">
                  <img src={l.product.image} alt={l.product.name} className="size-20 rounded-sm object-cover" loading="lazy" width={80} height={80} />
                  <div className="flex flex-1 flex-col">
                    <div className="flex justify-between gap-2">
                      <div>
                        <p className="font-display text-lg leading-tight">{l.product.name}</p>
                        {l.option && <p className="text-xs text-muted-foreground">{l.option}</p>}
                      </div>
                      <button onClick={() => remove(l.key)} aria-label={`Remove ${l.product.name}`} className="text-muted-foreground hover:text-foreground">
                        <X className="size-4" />
                      </button>
                    </div>
                    <div className="mt-auto flex items-center justify-between pt-3">
                      <div className="flex items-center border border-border">
                        <button className="p-2" aria-label="Decrease" onClick={() => setQty(l.key, l.qty - 1)}><Minus className="size-3" /></button>
                        <span className="w-6 text-center text-sm">{l.qty}</span>
                        <button className="p-2" aria-label="Increase" onClick={() => setQty(l.key, l.qty + 1)}><Plus className="size-3" /></button>
                      </div>
                      <p className="text-sm">{formatPrice(l.unitPrice * l.qty)}</p>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
            <div className="space-y-3 border-t border-border p-6 text-sm">
              <div className="flex justify-between text-muted-foreground"><span>Subtotal</span><span>{formatPrice(subtotal)}</span></div>
              <div className="flex justify-between text-muted-foreground"><span>Shipping</span><span>{shipping === 0 ? "Free" : formatPrice(shipping)}</span></div>
              <div className="flex justify-between font-display text-2xl"><span>Total</span><span>{formatPrice(total)}</span></div>
              <Button variant="lux" size="lg" className="mt-2 w-full" asChild onClick={() => setOpen(false)}>
                <Link to="/checkout">Checkout</Link>
              </Button>
            </div>
          </>
        )}
      </SheetContent>
    </Sheet>
  );
}
